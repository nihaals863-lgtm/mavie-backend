const express = require('express');
const router = express.Router();
const authRoutes = require('./auth');
const superadminRoutes = require('../modules/superadmin/routes');
const superadminController = require('../controllers/superadminController');
const notificationController = require('../controllers/notificationController');
const { authenticate, requireSuperAdmin, requireRole } = require('../middlewares/auth');
const companyRoutes = require('../modules/company/routes');
const userRoutes = require('../modules/users/routes');
const warehouseRoutes = require('./warehouses');
const zoneRoutes = require('./zones');
const locationRoutes = require('./locations');
const supplierRoutes = require('./suppliers');
const bundleRoutes = require('./bundles');
const inventoryRoutes = require('../modules/inventory/routes');
const orderRoutes = require('../modules/orders/routes');
const pickingRoutes = require('../modules/picking/routes');
const packingRoutes = require('../modules/packing/routes');
const shipmentRoutes = require('../modules/shipment/routes');
const purchaseOrderRoutes = require('./purchaseOrders');
const goodsReceivingRoutes = require('./goodsReceiving');
const replenishmentRoutes = require('./replenishment');
const returnRoutes = require('./returnRoutes');
const vatCodeRoutes = require('./vatCodeRoutes');
const labelsController = require('../controllers/labelsController');
const searchController = require('../controllers/searchController');

router.use('/auth', authRoutes);
const searchRoles = ['super_admin', 'company_admin', 'warehouse_manager', 'inventory_manager', 'viewer', 'picker', 'packer'];
router.get('/api/search', authenticate, requireRole(...searchRoles), searchController.search);
router.get('/api/labels', authenticate, requireRole('super_admin', 'company_admin', 'warehouse_manager', 'inventory_manager', 'packer', 'viewer'), labelsController.list);
// Super admin stats & reports (explicit so 404 doesn't happen)
router.get('/api/superadmin/stats', authenticate, requireSuperAdmin, superadminController.stats);
router.get('/api/superadmin/reports', authenticate, requireSuperAdmin, superadminController.reports);
router.use('/api/superadmin', superadminRoutes);
router.use('/api/company', companyRoutes);
router.use('/api/users', userRoutes);
router.use('/api/warehouses', warehouseRoutes);
router.use('/api/zones', zoneRoutes);
router.use('/api/locations', locationRoutes);
router.use('/api/suppliers', supplierRoutes);
router.use('/api/bundles', bundleRoutes);
router.use('/api/inventory', inventoryRoutes);
router.use('/api/orders', orderRoutes);
router.use('/api/picking', pickingRoutes);
router.use('/api/packing', packingRoutes);
router.use('/api/shipments', shipmentRoutes);
router.use('/api/purchase-orders', purchaseOrderRoutes);
router.use('/api/goods-receiving', goodsReceivingRoutes);
router.use('/api/replenishment', replenishmentRoutes);
router.use('/api/returns', returnRoutes);
router.use('/api/vat-codes', vatCodeRoutes);

// Notifications
router.get('/api/notifications', authenticate, notificationController.list);
router.put('/api/notifications/:id/read', authenticate, notificationController.markAsRead);
router.put('/api/notifications/read-all', authenticate, notificationController.markAllAsRead);

module.exports = router;
